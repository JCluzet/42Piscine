/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/05 17:02:31 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/05 17:44:49 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	gagner_des_lignes(char *str, int count)
{
	int lol;
	int retourn;

	lol = 0;
	retourn = 0;
	if ((str[count] == '\t' || str[count] == '\n' || str[count] == '\v' ||
		str[count] == '\f' || str[count] == '\r' ||
		str[count] == '-' || str[count] == '+' ||
		(str[count] >= '0' && str[count] <= '9')) ||
		(str[count] == ' ' && lol == 0))
		retourn = 0;
	else
		return (retourn);
	if (str[count] == ' ' && str[count + 1] != ' ' && lol == 0)
		lol = 1;
	return (retourn);
}

int	gagner_des_lignes_version_2(char *str, int resultat)
{
	int count;
	int moins;

	count = 0;
	moins = 0;
	while (str[count])
	{
		if (str[count] == '-')
			moins++;
		count++;
		if (str[count] <= '9' && str[count] >= '0')
			break ;
	}
	if (moins % 2 == 1)
	{
		resultat = resultat * -1;
		return (resultat);
	}
	else
		return (resultat);
}

int	ft_atoi(char *str)
{
	int count;
	int resultat;

	count = 0;
	resultat = 0;
	while (str[count])
	{
		if (gagner_des_lignes(str, count) == 0)
		{
			while (str[count] >= '0' && str[count] <= '9')
			{
				resultat = resultat * 10 + (str[count] - 48);
				count++;
				if (str[count] <= '0' || str[count] >= '9')
				{
					return (gagner_des_lignes_version_2(str, resultat));
				}
			}
			count++;
		}
		else
			return (0);
	}
	return (0);
}
