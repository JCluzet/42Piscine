/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/29 19:46:36 by jcluzet           #+#    #+#             */
/*   Updated: 2019/08/29 20:12:02 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char a)
{
	write(1, &a, 1);
}

void	ft_envoi(int a, int b, int c, int d)
{
	ft_putchar(a + 48);
	ft_putchar(b + 48);
	ft_putchar(' ');
	ft_putchar(c + 48);
	ft_putchar(d + 48);
	if (!(a == 9 && b == 8 && c == 9 && d == 9))
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	ft_print_comb2(void)
{
	int nb1;
	int nb2;

	nb1 = 0;
	nb2 = 0;
	while (!(nb1 == 98 && nb2 == 99))
	{
		nb2++;
		if (nb2 == 100)
		{
			nb2 = 0;
			nb1++;
		}
		if (!(nb1 == nb2) && nb1 < nb2)
		{
			ft_envoi(nb1 / 10, nb1 % 10, nb2 / 10, nb2 % 10);
		}
	}
}
