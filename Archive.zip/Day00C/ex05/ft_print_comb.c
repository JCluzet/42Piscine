/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/29 11:48:58 by jcluzet           #+#    #+#             */
/*   Updated: 2019/08/29 20:14:21 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_puchar(char c)
{
	write(1, &c, 1);
}

void	envoi(int a, int b, int c)
{
	if (c > b && b > a)
	{
		ft_puchar(a + 48);
		ft_puchar(b + 48);
		ft_puchar(c + 48);
		if (!(a == 7 && b == 8 && c == 9))
		{
			ft_puchar(',');
			ft_puchar(' ');
		}
	}
}

void	ft_print_comb(void)
{
	int number001;
	int number010;
	int number100;

	number001 = 0;
	number010 = 0;
	number100 = 0;
	while (!(number001 == 9 && number010 == 8 && number100 == 7))
	{
		number001++;
		if (number001 == 10)
		{
			number001 = 0;
			number010 = number010 + 1;
		}
		if (number010 == 10)
		{
			number010 = 0;
			number100 = number100 + 1;
		}
		envoi(number100, number010, number001);
	}
}

int main(void)
{
	ft_print_comb();
	return (0);
}