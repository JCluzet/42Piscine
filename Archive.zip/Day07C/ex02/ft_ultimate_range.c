/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/10 14:37:20 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/10 15:26:31 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int i;
	int *str;

	i = 0;
	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	str = malloc(sizeof(int) * (max - min));
	if (str == NULL)
		return (-1);
	while (i < (max - min))
	{
		str[i] = min + i;
		i++;
	}
	*range = str;
	return (i);
}
