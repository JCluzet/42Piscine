/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/11 15:03:11 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/11 17:47:43 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int		nombredecaractere(int size, char **strs, char *sep)
{
	int i;
	int j;
	int caractere;

	caractere = 0;
	i = 0;
	j = 0;
	if (size <= 0)
		return (1);
	while (i < size)
	{
		while (strs[i][j])
			j++;
		i++;
		caractere = j + caractere;
		j = 0;
	}
	while (sep[j])
		j++;
	caractere = caractere + (j * (size - 1) + 1);
	return (caractere);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		caracteretotal;
	char	*str;
	int		i;
	int		j;
	int		u;

	i = 0;
	j = 0;
	u = 0;
	caracteretotal = nombredecaractere(size, strs, sep);
	str = malloc(sizeof(char) * caracteretotal);
	while (i < size && size != 0)
	{
		j = 0;
		while (strs[i][j])
			str[u++] = strs[i][j++];
		j = 0;
		while (sep[j] && u != caracteretotal - 1)
			str[u++] = sep[j++];
		i++;
	}
	str[u] = '\0';
	return (str);
}
