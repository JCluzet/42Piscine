/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/10 13:30:13 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/10 14:36:56 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int	*ft_range(int min, int max)
{
	int *tableauint;
	int i;

	i = 0;
	if (min >= max)
	{
		tableauint = NULL;
		return (tableauint);
	}
	tableauint = malloc(sizeof(int) * (max - min));
	if (tableauint == NULL)
		return (NULL);
	while (i < max - min)
	{
		tableauint[i] = min + i;
		i++;
	}
	return (tableauint);
}
