/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/14 21:55:22 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/15 00:50:18 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include <stdlib.h>

int					ft_strlen(char *src)
{
	int i;

	i = 0;
	while (src[i])
		i++;
	return (i);
}

char				*ft_strdup(char *src)
{
	char	*moulitruc;
	int		i;
	int		u;

	i = 0;
	u = ft_strlen(src);
	moulitruc = malloc(sizeof(char) * u + 1);
	if (moulitruc == NULL)
		return (NULL);
	while (src[i])
	{
		moulitruc[i] = src[i];
		i++;
	}
	moulitruc[i] = '\0';
	return (moulitruc);
}

struct	s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	t_stock_str		*ouille;
	int				i;

	i = 0;
	if (!(ouille = malloc(sizeof(t_stock_str) * (ac + 1))))
		return (NULL);
	while (i < ac)
	{
		ouille[i].size = ft_strlen(av[i]);
		ouille[i].str = av[i];
		ouille[i].copy = ft_strdup(ouille[i].str);
		i++;
	}
	ouille[i].str = 0;
	return (ouille);
}
