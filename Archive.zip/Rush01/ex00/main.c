/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush_01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/07 16:55:11 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/08 11:35:42 by bvalette         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void	sortnumbers(char *str);

int		checkargumenterror(char *str)
{
	int count;

	count = 0;
	if(str[31] != '\0')
		return(1);
	while (str[count])
	{
		if (str[count] <= '4' && str[count] >= '1')
			count++;
		else
			return (1);
		if (count == 31)
			break ;
		if (str[count] == ' ')
			count++;
		else
			return (1);
	}
	if (count == 31)
		return (0);
	else
		return (1);
}

void	error(void)
{
	write(1, "Error\n", 7);
}

int		main(int argc, char **argv)
{
	if(argc != 2)
		return(1);
	if (checkargumenterror(argv[1]) == 0)
	{
		printf("Ok !\n");
		sortnumbers(argv[1]);
	}
	else
		error();
	return (0);
}
