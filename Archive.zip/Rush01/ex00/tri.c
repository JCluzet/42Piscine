/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   populate_map.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bvalette <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/07 16:41:13 by bvalette          #+#    #+#             */
/*   Updated: 2019/09/08 12:23:24 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	main()
{
//	int	col_up[3] = {4, 3, 2, 1};
	int map[3][3];
	int x;
	int y;
	int n;
	int i;

	x = 0;
	y = 0;
	n = 4;
	while (y <= 3)
	{
		while (x <= 3)
		{
		
			while (n >= 1)
			{
			map[y][x] = n;
			n--;
			x++;
			}
		n = 4;
		x = 0;
		}
	y++;
	}

i = 0;
while (i <= 3)
	{
	printf("%d ", map[0][i]);	
	i++;
	}
i = 0;
printf("\n");	
while (i <= 3)
	{
	printf("%d ", map[1][i]);	
	i++;
	}
printf("\n");	
i = 0;
while (i <= 3)
	{
	printf("%d ", map[2][i]);	
	i++;
	}
printf("\n");	
i = 0;
while (i <= 3)
	{
	printf("%d ", map[3][i]);	
	i++;
	}
printf("\n");	
}	
