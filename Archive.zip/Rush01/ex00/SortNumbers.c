/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sortnumbers.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/07 17:10:13 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/08 10:40:30 by bvalette         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		sortcolup(char *str)
{
	int count;
	int count2;
	int colup[4];

	count = 0;
	count2 = 0;
	while (count < 8)
	{
		colup[count2] = str[count] - 48;
		count2++;
		count = count + 2;
	}
	return (*colup);
}

int		sortcoldown(char *str)
{
	int count;
	int count2;
	int coldown[4];

	count = 8;
	count2 = 0;
	while (count < 16)
	{
		coldown[count2] = str[count] - 48;
		count2++;
		count = count + 2;
	}
	return (*coldown);
}

int		sortrowleft(char *str)
{
	int count;
	int count2;
	int rowleft[4];

	count = 16;
	count2 = 0;
	while (count < 24)
	{
		rowleft[count2] = str[count] - 48;
		count2++;
		count = count + 2;
	}
	return (*rowleft);
}

int		sortrowright(char *str)
{
	int count;
	int count2;
	int rowright[4];

	count = 24;
	count2 = 0;
	while (count < 31)
	{
		rowright[count2] = str[count] - 48;
		count2++;
		count = count + 2;
	}
	return (*rowright);
}

void	sortnumbers(char *str)
{
	sortcolup(str);
	sortcoldown(str);
	sortrowleft(str);
	sortrowright(str);
}
