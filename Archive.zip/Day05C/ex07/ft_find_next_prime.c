/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/08 18:02:02 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/08 18:02:18 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_number_is_prime(int nb)
{
	int i;
	int jb;

	i = 2;
	if (nb < 0 || nb == 0 || nb == 1)
		return (0);
	while (i < nb)
	{
		jb = nb % i;
		if (jb == 0)
			return (0);
		i++;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	if (nb <= 2)
		return (2);
	while (1)
	{
		if (ft_number_is_prime(nb))
			return (nb);
		nb++;
	}
}
