/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/08 16:05:09 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/08 16:06:54 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_f(unsigned int n, unsigned int nb1, unsigned int nb2)
{
	if (n == 1)
		return (nb2);
	return (ft_f(n - 1, nb2, nb2 + nb1));
}

int				ft_fibonacci(int index)
{
	if (index < 0)
		return (-1);
	if (index == 0)
		return (0);
	return (ft_f(index, 0, 1));
}
