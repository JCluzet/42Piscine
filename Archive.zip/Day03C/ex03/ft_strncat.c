/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/03 16:54:22 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/03 17:36:17 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int count;
	unsigned int count2;

	count2 = 0;
	count = 0;
	while (dest[count] != '\0')
	{
		count++;
	}
	while (src[count2] != '\0' && count2 < nb)
	{
		dest[count] = src[count2];
		count2++;
		count++;
	}
	dest[count] = '\0';
	return (dest);
}
