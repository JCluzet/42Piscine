/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcluzet <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/03 17:40:27 by jcluzet           #+#    #+#             */
/*   Updated: 2019/09/05 16:24:06 by jcluzet          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strstr(char *str, char *to_find)
{
	int	count;
	int count2;

	count2 = 0;
	count = 0;
	if (to_find[count2] == '\0')
		return (str);
	while (str[count])
	{
		while (to_find[count2] == str[count + count2])
		{
			if (to_find[count2 + 1] == '\0')
				return (str + count);
			count2++;
		}
		count++;
		count2 = 0;
	}
	return (0);
}

int	main(void)
{
	char str[] = "Salut comment tu va ?";
	char to_find[] = "commen";
	printf("MA FONCTION   >> %s\n", ft_strstr(str, to_find));
	printf("VRAI FONCTION >> %s\n", strstr(str, to_find));
	return(0);
}